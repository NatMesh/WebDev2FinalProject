<?php 
	include 'header.php';

	$userId = filter_input(INPUT_GET, 'userId', FILTER_SANITIZE_NUMBER_INT);
	$validateUserId = filter_input(INPUT_GET, 'userId', FILTER_VALIDATE_INT);

	$firstName = filter_input(INPUT_GET, 'firstName', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

	if($validateUserId){
		//This query will grab all the players belonging to a user's team.
		$query = "SELECT * FROM nbaplayers WHERE userID = :userID";
		$statement = $db->prepare($query);
		$statement->bindValue(':userID', $userId);
		$statement->execute();
		$userFantasyTeam = $statement->fetchAll();
	}else{
		header('Location: HomePage.php');
	}

	$query2 = "SELECT comment, Date, firstName FROM comments WHERE teamPageId = :userId";
	$statement2 = $db->prepare($query2);
	$statement2->bindValue(':userId', $userId);
	$statement2->execute();
	$teamPageComments = $statement2->fetchAll();

?> 

<!DOCTYPE html>
<html>
<head>
	<title>Team Roster</title>
	<link rel="stylesheet" type="text/css" href="TeamRoster.css"/>
</head>
<body>
	<h1><?= $firstName ?>'s Team</h1>

	<table>
		<tr>
			<th>NAME</th>
			<th>POS</th>
			<th>MIN</th>
			<th>FT%</th>
			<th>eFG%</th>
			<th>PTS</th>
			<th>REB</th>
			<th>AST</th>
			<th>STL</th>
			<th>BLK</th>
			<th>REMOVE PLAYER</th>
		</tr>
		<?php foreach($userFantasyTeam as $player): ?>
			<tr>
				<td><?= $player['NAME'] ?></td>
				<td><?= $player['POS'] ?></td>
				<td><?= $player['MIN'] ?></td>
				<td><?= $player['FT%'] ?></td>
				<td><?= $player['eFG%'] ?></td>
				<td><?= $player['PTS'] ?></td>
				<td><?= $player['REB'] ?></td>
				<td><?= $player['AST'] ?></td>
				<td><?= $player['STL'] ?></td>
				<td><?= $player['BLK'] ?></td>
				<td><h4><a href="">REMOVE</a></h4></td>
			</tr>
		<?php endforeach ?>
	</table>

	<form action="addComment.php" method="POST">

		<label>Comment:</label>

			<textarea name="comment" placeholder="Make a comment.."></textarea>

			<input type="hidden" name="teamPageId" value="<?= $userId ?>">
		<input type="submit" name="post" value="Post">
	</form>

	<h3>All Comments:</h3>
	<?php foreach($teamPageComments as $teamPageComment): ?>
		<p><b><?= $teamPageComment['firstName']?>            </b><span><?= $teamPageComment['Date']?></span></p> 
		<p class="seperate_comments"><?= $teamPageComment['comment'] ?></p>
	<?php endforeach ?>
	

</body>
</html>